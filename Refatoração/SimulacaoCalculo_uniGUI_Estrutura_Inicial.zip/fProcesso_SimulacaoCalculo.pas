unit fProcesso_SimulacaoCalculo;

interface

uses
  Winapi.Windows, System.SysUtils, System.Classes, Data.DB, FireDAC.Comp.Client,
  uniGUIClasses, uniGUIBaseClasses, uniGUIFrame, uniPanel, uniPageControl,
  uniDBGrid, uniDBNavigator, uniDBEdit, uniDBMemo, uniDBCheckBox,
  uniDBComboBox, uniDBDateTimePicker, uniDBLookUpComboBox, uniButton,
  uniSpeedButton, uniLabel, uniGroupBox, uniMemo, uniEdit, uniNumberEdit,
  uniDateTimePicker, uniCheckBox, uniComboBox;

type
  TfProcesso_SimulacaoCalculo = class(TUniFrame)
    RxLabel3: TUniLabel;
    RxLabel4: TUniLabel;
    PageControl1: TUniPageControl;
    TabSheet1: TUniTabSheet;
    Panel5: TUniPanel;
    Label3: TUniLabel;
    StaticText44: TUniLabel;
    lData: TUniLabel;
    StaticText3: TUniLabel;
    StaticText5: TUniLabel;
    StaticText8: TUniLabel;
    cNumero: TUniDBEdit;
    DBEdit5: TUniDBEdit;
    DBEdit11: TUniDBEdit;
    DBEdit17: TUniDBEdit;
    StaticText11: TUniLabel;
    StaticText14: TUniLabel;
    StaticText15: TUniLabel;
    DBEdit18: TUniDBEdit;
    DBEdit20: TUniDBEdit;
    cTaxaMoeda: TUniDBEdit;
    DBEdit24: TUniDBEdit;
    DBEdit25: TUniDBEdit;
    StaticText16: TUniLabel;
    StaticText18: TUniLabel;
    StaticText21: TUniLabel;
    StaticText22: TUniLabel;
    StaticText23: TUniLabel;
    DBEdit32: TUniDBEdit;
    StaticText29: TUniLabel;
    cDataRegistro_DI: TUniDBDateTimePicker;
    StaticText31: TUniLabel;
    StaticText32: TUniLabel;
    RxDBLookupCombo1: TUniDBLookupComboBox;
    RxDBLookupCombo2: TUniDBLookupComboBox;
    StaticText39: TUniLabel;
    DBEdit1: TUniDBEdit;
    StaticText40: TUniLabel;
    DBEdit2: TUniDBEdit;
    DBEdit4: TUniDBEdit;
    DBEdit8: TUniDBEdit;
    DBEdit28: TUniDBEdit;
    DBEdit29: TUniDBEdit;
    StaticText43: TUniLabel;
    StaticText45: TUniLabel;
    cVia: TUniDBComboBox;
    RxDBLookupCombo3: TUniDBLookupComboBox;
    StaticText47: TUniLabel;
    RxDBLookupCombo4: TUniDBLookupComboBox;
    StaticText48: TUniLabel;
    StaticText49: TUniLabel;
    DBEdit7: TUniDBEdit;
    DBEdit16: TUniDBEdit;
    StaticText50: TUniLabel;
    DBEdit36: TUniDBEdit;
    StaticText51: TUniLabel;
    RxDBLookupCombo5: TUniDBLookupComboBox;
    StaticText52: TUniLabel;
    DBEdit37: TUniDBEdit;
    DBComboBox1: TUniDBComboBox;
    StaticText10: TUniLabel;
    StaticText27: TUniLabel;
    RxDBLookupCombo7: TUniDBLookupComboBox;
    GroupBox1: TUniGroupBox;
    cNomeClienteImp: TUniDBEdit;
    StaticText1: TUniLabel;
    StaticText28: TUniLabel;
    RxDBLookupCombo8: TUniDBLookupComboBox;
    GroupBox2: TUniGroupBox;
    StaticText34: TUniLabel;
    StaticText35: TUniLabel;
    DBEdit19: TUniDBEdit;
    DBCheckBox1: TUniDBCheckBox;
    DBCheckBox2: TUniDBCheckBox;
    DBCheckBox3: TUniDBCheckBox;
    RxDBLookupCombo9: TUniDBLookupComboBox;
    DBCheckBox4: TUniDBCheckBox;
    DBCheckBox5: TUniDBCheckBox;
    DBCheckBox6: TUniDBCheckBox;
    StaticText36: TUniLabel;
    RxDBLookupCombo10: TUniDBLookupComboBox;
    StaticText37: TUniLabel;
    DBEdit3: TUniDBEdit;
    StaticText38: TUniLabel;
    DBEdit6: TUniDBEdit;
    StaticText54: TUniLabel;
    DBEdit22: TUniDBEdit;
    StaticText58: TUniLabel;
    RxDBLookupCombo11: TUniDBLookupComboBox;
    StaticText60: TUniLabel;
    DBEdit40: TUniDBEdit;
    DBEdit41: TUniDBEdit;
    StaticText61: TUniLabel;
    RxDBLookupCombo12: TUniDBLookupComboBox;
    StaticText67: TUniLabel;
    DBEdit47: TUniDBEdit;
    GroupBox3: TUniGroupBox;
    StaticText69: TUniLabel;
    DBEdit49: TUniDBEdit;
    StaticText70: TUniLabel;
    DBEdit50: TUniDBEdit;
    DBEdit51: TUniDBEdit;
    StaticText71: TUniLabel;
    StaticText72: TUniLabel;
    DBEdit52: TUniDBEdit;
    StaticText73: TUniLabel;
    DBEdit53: TUniDBEdit;
    StaticText68: TUniLabel;
    DBEdit48: TUniDBEdit;
    StaticText124: TUniLabel;
    DBEdit54: TUniDBEdit;
    StaticText53: TUniLabel;
    RxDBLookupCombo6: TUniDBLookupComboBox;
    StaticText19: TUniLabel;
    DBEdit21: TUniDBEdit;
    StaticText9: TUniLabel;
    cSeguro: TUniDBEdit;
    StaticText24: TUniLabel;
    DBEdit26: TUniDBEdit;
    TabSheet2: TUniTabSheet;
    Panel6: TUniPanel;
    StaticText2: TUniLabel;
    cProduto: TUniDBEdit;
    StaticText4: TUniLabel;
    cNCM: TUniDBEdit;
    StaticText7: TUniLabel;
    DBEdit10: TUniDBEdit;
    StaticText17: TUniLabel;
    cUnitario: TUniDBEdit;
    StaticText6: TUniLabel;
    DBEdit9: TUniDBEdit;
    StaticText12: TUniLabel;
    cAliquotaII: TUniDBEdit;
    StaticText13: TUniLabel;
    cAliquotaIPI: TUniDBEdit;
    StaticText25: TUniLabel;
    cAliquotaPIS: TUniDBEdit;
    StaticText26: TUniLabel;
    cAliquotaCOFINS: TUniDBEdit;
    cPesoBruto: TUniDBEdit;
    StaticText41: TUniLabel;
    DBEdit13: TUniDBEdit;
    DBEdit14: TUniDBEdit;
    DBEdit15: TUniDBEdit;
    DBEdit23: TUniDBEdit;
    cUnitarioReal: TUniNumberEdit;
    StaticText42: TUniLabel;
    StaticText46: TUniLabel;
    DBEdit35: TUniDBEdit;
    DBEdit33: TUniDBEdit;
    StaticText55: TUniLabel;
    DBEdit12: TUniDBEdit;
    StaticText56: TUniLabel;
    DBEdit27: TUniDBEdit;
    DBEdit30: TUniDBEdit;
    DBEdit31: TUniDBEdit;
    StaticText57: TUniLabel;
    DBEdit34: TUniDBEdit;
    DBEdit38: TUniDBEdit;
    StaticText63: TUniLabel;
    DBEdit43: TUniDBEdit;
    DBEdit44: TUniDBEdit;
    StaticText64: TUniLabel;
    DBEdit45: TUniDBEdit;
    cTotalII: TUniNumberEdit;
    cTotalIPI: TUniNumberEdit;
    DBEdit46: TUniDBEdit;
    GradeProd: TUniDBGrid;
    Panel4: TUniPanel;
    NavegaProdutos: TUniDBNavigator;
    bDuplicarItem: TUniButton;
    StaticText62: TUniLabel;
    DBEdit42: TUniDBEdit;
    TabSheet3: TUniTabSheet;
    gDespesas: TUniDBGrid;
    Panel3: TUniPanel;
    bRemoveTudo: TUniButton;
    bBuscar: TUniButton;
    bMarinha: TUniButton;
    NavegaDesp: TUniDBNavigator;
    bPISCOFINS: TUniButton;
    StaticText30: TUniLabel;
    cTotalDespesasSai: TUniNumberEdit;
    cTotalDespesas: TUniNumberEdit;
    Panel2: TUniPanel;
    bPesq: TUniSpeedButton;
    StaticText20: TUniLabel;
    StaticText33: TUniLabel;
    cDespNac: TUniNumberEdit;
    StaticText59: TUniLabel;
    cValorME: TUniNumberEdit;
    StaticText65: TUniLabel;
    cTaxa: TUniNumberEdit;
    DBEdit39: TUniDBEdit;
    StaticText66: TUniLabel;
    TabSheet5: TUniTabSheet;
    DBGrid1: TUniDBGrid;
    TabSheet4: TUniTabSheet;
    Memo1: TUniMemo;
    Panel1: TUniPanel;
    bCalcular: TUniSpeedButton;
    bSair: TUniButton;
    bImprimir: TUniButton;
    Navega: TUniDBNavigator;
    bExcel: TUniButton;
    bDuplicar: TUniButton;
    bImpHor: TUniButton;
    tNumero: TFDQuery;
    tDespesa: TFDQuery;
    tRegistro: TFDQuery;
    tSomaDespesas: TFDQuery;
    tItens: TFDQuery;
    tSomaProdutos: TFDQuery;
    tSomaImpostos: TFDQuery;
    tProdutos: TFDQuery;
    tSimula: TFDQuery;
    dstSimula: TDataSource;
    dstProdutos: TDataSource;
    dstDespesa: TDataSource;
    tDespesaAdm: TFDQuery;
    dstDespesaAdm: TDataSource;
    tDespesaSai: TFDQuery;
    dstDespesaSai: TDataSource;
    ttmp: TFDQuery;
    tDespesaMar: TFDQuery;
    dstDespesaMar: TDataSource;
    procedure UniFrameCreate(Sender: TObject);
    procedure UniFrameDestroy(Sender: TObject);
  end;

implementation

uses MainModule;

{$R *.dfm}

procedure TfProcesso_SimulacaoCalculo.UniFrameCreate(Sender: TObject);
var
  i: Integer;
begin
  for i := 0 to ComponentCount - 1 do
    if Components[i] is TFDQuery then
      TFDQuery(Components[i]).Connection := UniMainModule.Conecta;
end;

procedure TfProcesso_SimulacaoCalculo.UniFrameDestroy(Sender: TObject);
var
  i: Integer;
begin
  for i := 0 to ComponentCount - 1 do
    if Components[i] is TFDQuery then
      TFDQuery(Components[i]).Close;
end;

end.
