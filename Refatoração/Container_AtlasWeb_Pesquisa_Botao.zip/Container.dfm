object fContainer: TfContainer
  Left = 0
  Top = 0
  Width = 1190
  Height = 790
  OnCreate = UniFrameCreate
  TabOrder = 0
  object pBarraNav: TUniPanel
    Left = 0
    Top = 0
    Width = 1190
    Height = 35
    Align = alTop
    Caption = ''
    ClientEvents.UniEvents.Strings = (
      'beforeInit=function beforeInit(sender, config)'#13#10'{'#13#10'  config.cls = '#39'Pasta'#39';'#13#10'}')
    BorderStyle = ubsNone
    Color = 5526569
    TabOrder = 0
    object Navega: TUniDBNavigator
      Left = 0
      Top = 0
      Width = 164
      Height = 35
      DataSource = dsContainer
      VisibleButtons = [nbFirst, nbPrior, nbNext, nbLast]
      IconSet = icsFontAwesome
      Align = alLeft
      TabOrder = 11
    end
    object bAdicionar: TUniSpeedButton
      Left = 164
      Top = 0
      Width = 41
      Height = 35
      Caption = ''
      TabOrder = 0
      OnClick = bAdicionarClick
      Hint = 'Adicionar registro'
      Align = alLeft
      ParentColor = False
      IconAlign = iaCenter
      Images = UniMainModule.imgBotoes
      ImageIndex = 0
    end
    object bEditar: TUniSpeedButton
      Left = 205
      Top = 0
      Width = 41
      Height = 35
      Caption = ''
      TabOrder = 1
      OnClick = bEditarClick
      Hint = 'Editar registro'
      Align = alLeft
      ParentColor = False
      IconAlign = iaCenter
      Images = UniMainModule.imgBotoes
      ImageIndex = 1
    end
    object bExcluir: TUniSpeedButton
      Left = 246
      Top = 0
      Width = 41
      Height = 35
      Caption = ''
      TabOrder = 2
      OnClick = bExcluirClick
      Hint = 'Excluir registro'
      Align = alLeft
      ParentColor = False
      IconAlign = iaCenter
      Images = UniMainModule.imgBotoes
      ImageIndex = 2
    end
    object bGravar: TUniSpeedButton
      Left = 287
      Top = 0
      Width = 41
      Height = 35
      Caption = ''
      TabOrder = 3
      OnClick = bGravarClick
      Hint = 'Salvar registro'
      Align = alLeft
      ParentColor = False
      IconAlign = iaCenter
      Images = UniMainModule.imgBotoes
      ImageIndex = 4
    end
    object bCancelar: TUniSpeedButton
      Left = 328
      Top = 0
      Width = 41
      Height = 35
      Caption = ''
      TabOrder = 4
      OnClick = bCancelarClick
      Hint = 'Cancelar altera��es'
      Align = alLeft
      ParentColor = False
      IconAlign = iaCenter
      Images = UniMainModule.imgBotoes
      ImageIndex = 3
    end
    object bSair: TUniSpeedButton
      Left = 369
      Top = 0
      Width = 41
      Height = 35
      Caption = ''
      TabOrder = 6
      OnClick = bSairClick
      Hint = 'Fechar m�dulo'
      Align = alLeft
      ParentColor = False
      IconAlign = iaCenter
      Images = UniMainModule.imgBotoes
      ImageIndex = 7
    end
  end
  object Pasta: TUniPageControl
    Left = 0
    Top = 35
    Width = 1190
    Height = 748
    Align = alClient
    ActivePage = aLista
    TabOrder = 1
    ClientEvents.UniEvents.Strings = (
      'beforeInit=function beforeInit(sender, config)'#13#10'{'#13#10'  config.cls = '#39'PastaInterna'#39';'#13#10'}')
    object aLista: TUniTabSheet
      Caption = 'Lista'
      object pBarraPesq: TUniPanel
        Left = 0
        Top = 0
        Width = 1182
        Height = 40
        Align = alTop
        Caption = ''
        ClientEvents.UniEvents.Strings = (
          'beforeInit=function beforeInit(sender, config)'#13#10'{'#13#10'  config.cls = '#39'BarraPesquisa'#39';'#13#10'}')
        BorderStyle = ubsNone
        Color = clNone
        TabOrder = 0
        object cPesquisa: TUniEdit
          Left = 12
          Top = 7
          Width = 310
          Height = 26
          EmptyText = 'Container / Processo / Documento de carga'
          TabOrder = 0
          OnKeyDown = cPesquisaKeyDown
        end
        object bPesquisa: TUniSpeedButton
          Left = 329
          Top = 3
          Width = 41
          Height = 34
          Caption = ''
          TabOrder = 1
          OnClick = bPesquisaClick
          Hint = 'Pesquisar registro'
                    ParentColor = False
          IconAlign = iaCenter
          Images = UniMainModule.imgBotoes
          ImageIndex = 10
        end
        object cTravar: TUniCheckBox
          Left = 390
          Top = 10
          Width = 270
          Height = 22
          Caption = 'Copiar dados do container anterior'
          TabOrder = 0
          OnClick = cTravarClick
        end
      end
      object Grade: TUniDBGrid
        Left = 0
        Top = 40
        Width = 1182
        Height = 670
        Align = alClient
        DataSource = dsContainer
        ReadOnly = True
        TabOrder = 1
      end
    end
    object aFicha: TUniTabSheet
      Caption = 'Ficha'
      object pFicha: TUniScrollBox
        Left = 0
        Top = 0
        Width = 1182
        Height = 670
        Align = alClient
        TabOrder = 0
        ClientEvents.UniEvents.Strings = (
          'beforeInit=function beforeInit(sender, config)'#13#10'{'#13#10'  config.cls = '#39'Pasta'#39';'#13#10'}')
        object pFicha1: TUniPanel
          Left = 120
          Top = 20
          Width = 920
          Height = 1050
          Hint = ''
          ShowHint = True
          ParentShowHint = False
          Anchors = [akTop]
          TabOrder = 0
          ClientEvents.UniEvents.Strings = (
            'beforeInit=function beforeInit(sender, config)'#13#10'{'#13#10' config.cls = '#39'Ficha'#39';'#13#10'}')
          BorderStyle = ubsSolid
          TitleAlign = taCenter
          Title = 'Dados do Container'
          Caption = ''
          object cProcesso: TUniDBLookupComboBox
            Left = 21
            Top = 19
            Width = 420
            Height = 25
            DataField = 'Processo'
            DataSource = dsContainer
            TabOrder = 0
            ListSource = dsProcessosDOC
            KeyField = 'Processo'
            ListField = 'Processo'
            OnChange = cProcessoChange
            FieldLabel = 'Processo'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object cNumero: TUniDBEdit
            Left = 21
            Top = 46
            Width = 420
            Height = 25
            DataField = 'Numero'
            DataSource = dsContainer
            TabOrder = 1
            OnChange = cNumeroChange
            OnExit = cNumeroExit
            FieldLabel = 'N� container'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object cTipoEmbarque: TUniDBComboBox
            Left = 21
            Top = 73
            Width = 420
            Height = 25
            DataField = 'Tipo_Embarque'
            DataSource = dsContainer
            TabOrder = 2
            Items.Strings = (
              'A�REO'
              'FCL'
              'LCL - INTEGRAL'
              'LCL - PARTE'
              'MAR�TIMO'
              'OUTROS')
            OnExit = cTipoEmbarqueExit
            FieldLabel = 'Tipo embarque'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBEdit13: TUniDBEdit
            Left = 21
            Top = 100
            Width = 420
            Height = 25
            DataField = 'Documento_Carga'
            DataSource = dsContainer
            TabOrder = 3
            FieldLabel = 'Documento carga'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBEdit9: TUniDBEdit
            Left = 21
            Top = 127
            Width = 420
            Height = 25
            DataField = 'Tipo'
            DataSource = dsContainer
            TabOrder = 4
            FieldLabel = 'Tipo'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBEdit10: TUniDBEdit
            Left = 21
            Top = 154
            Width = 420
            Height = 25
            DataField = 'Tamanho'
            DataSource = dsContainer
            TabOrder = 5
            FieldLabel = 'Tamanho'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBEdit11: TUniDBEdit
            Left = 21
            Top = 181
            Width = 420
            Height = 25
            DataField = 'Armador'
            DataSource = dsContainer
            TabOrder = 6
            FieldLabel = 'Armador'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBEdit1: TUniDBEdit
            Left = 21
            Top = 208
            Width = 420
            Height = 25
            DataField = 'Terminal'
            DataSource = dsContainer
            TabOrder = 7
            FieldLabel = 'Terminal'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBDateEdit3: TUniDBDateTimePicker
            Left = 21
            Top = 235
            Width = 420
            Height = 25
            DataField = 'Data_Entrada'
            DataSource = dsContainer
            TabOrder = 8
            OnExit = cFreeTimeExit
            FieldLabel = 'Data entrada'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBEdit4: TUniDBEdit
            Left = 21
            Top = 262
            Width = 420
            Height = 25
            DataField = 'Hora_Entrada'
            DataSource = dsContainer
            TabOrder = 9
            OnExit = DBEdit4Exit
            FieldLabel = 'Hora entrada'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBDateEdit1: TUniDBDateTimePicker
            Left = 21
            Top = 289
            Width = 420
            Height = 25
            DataField = 'Data_Saida'
            DataSource = dsContainer
            TabOrder = 10
            FieldLabel = 'Data sa�da'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBEdit6: TUniDBEdit
            Left = 462
            Top = 19
            Width = 420
            Height = 25
            DataField = 'Hora_Saida'
            DataSource = dsContainer
            TabOrder = 11
            FieldLabel = 'Hora sa�da'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object cFreeTime: TUniDBEdit
            Left = 462
            Top = 46
            Width = 420
            Height = 25
            DataField = 'Free_Time'
            DataSource = dsContainer
            TabOrder = 12
            OnExit = cFreeTimeExit
            FieldLabel = 'Free time'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object cValorDemurrage: TUniDBEdit
            Left = 462
            Top = 73
            Width = 420
            Height = 25
            DataField = 'Valor_Demurrage'
            DataSource = dsContainer
            TabOrder = 13
            OnChange = cValorDemurrageChange
            FieldLabel = 'Valor demurrage'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object cTaxa: TUniDBEdit
            Left = 462
            Top = 100
            Width = 420
            Height = 25
            DataField = 'Taxa'
            DataSource = dsContainer
            TabOrder = 14
            OnChange = cValorDemurrageChange
            FieldLabel = 'Taxa'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object cArmazem: TUniDBLookupComboBox
            Left = 462
            Top = 127
            Width = 420
            Height = 25
            DataField = 'Armazem'
            DataSource = dsContainer
            TabOrder = 15
            ListSource = dsArmazens
            KeyField = 'Codigo'
            ListField = 'Nome'
            FieldLabel = 'Armaz�m'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBLookupComboBox3: TUniDBLookupComboBox
            Left = 462
            Top = 154
            Width = 420
            Height = 25
            DataField = 'Transportadora_Entrada'
            DataSource = dsContainer
            TabOrder = 16
            ListSource = dsFornecedores
            KeyField = 'Codigo'
            ListField = 'Nome'
            FieldLabel = 'Transportadora entrada'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBLookupComboBox4: TUniDBLookupComboBox
            Left = 462
            Top = 181
            Width = 420
            Height = 25
            DataField = 'Transportadora_Saida'
            DataSource = dsContainer
            TabOrder = 17
            ListSource = dsFornecedores
            KeyField = 'Codigo'
            ListField = 'Nome'
            FieldLabel = 'Transportadora sa�da'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object cDataEntrega: TUniDBDateTimePicker
            Left = 462
            Top = 208
            Width = 420
            Height = 25
            DataField = 'Data_Entrega'
            DataSource = dsContainer
            TabOrder = 18
            OnExit = cDataEntregaExit
            FieldLabel = 'Data entrega'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBEdit2: TUniDBEdit
            Left = 462
            Top = 235
            Width = 420
            Height = 25
            DataField = 'Hora_Entrega'
            DataSource = dsContainer
            TabOrder = 19
            FieldLabel = 'Hora entrega'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
            SelectOnFocus = True
          end
          object DBDateEdit4: TUniDBDateTimePicker
            Left = 462
            Top = 262
            Width = 420
            Height = 25
            DataField = 'Data_Pagamento'
            DataSource = dsContainer
            TabOrder = 20
            FieldLabel = 'Data pagamento'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object DBMemo1: TUniDBMemo
            Left = 21
            Top = 330
            Width = 420
            Height = 85
            DataField = 'Observacao'
            DataSource = dsContainer
            TabOrder = 21
            FieldLabel = 'Observa��es'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
          end
          object cMemoProcessos: TUniDBMemo
            Left = 462
            Top = 330
            Width = 420
            Height = 85
            DataField = 'Memo_Processos'
            DataSource = dsContainer
            TabOrder = 22
            FieldLabel = 'Processos adicionais'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
          end
          object cAdicionarProcesso: TUniComboBox
            Left = 21
            Top = 438
            Width = 420
            Height = 25
            TabOrder = 25
            FieldLabel = 'Adicionar processo'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
          end
          object bAdicionarProcesso: TUniButton
            Left = 462
            Top = 438
            Width = 165
            Height = 25
            Caption = 'Adicionar processo'
            TabOrder = 26
            OnClick = bAdicionarProcessoClick
          end
          object cDemurrage: TUniEdit
            Left = 21
            Top = 492
            Width = 270
            Height = 25
            ReadOnly = True
            TabOrder = 27
            FieldLabel = 'Dias de demurrage'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object cTotalME: TUniEdit
            Left = 21
            Top = 519
            Width = 270
            Height = 25
            ReadOnly = True
            TabOrder = 28
            FieldLabel = 'Total moeda estrangeira'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
          object cTotalReal: TUniEdit
            Left = 21
            Top = 546
            Width = 270
            Height = 25
            ReadOnly = True
            TabOrder = 29
            FieldLabel = 'Total em reais'
            FieldLabelWidth = 135
            FieldLabelSeparator = ' '
            BorderStyle = ubsInset
          end
        end
      end
    end
  end
  object Alerta: TUniSweetAlert
    Left = 480
    Top = 705
  end
  object Container: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 40
    Top = 705
    OnAfterScroll = ContainerAfterScroll
    OnBeforePost = ContainerBeforePost
  end
  object ProcessosDOC: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 112
    Top = 705
  end
  object Armazens: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 184
    Top = 705
    object ArmazensCodigo: TIntegerField
      FieldName = 'Codigo'
    end
    object ArmazensNome: TStringField
      FieldName = 'Nome'
      Size = 60
    end
    object ArmazensCNPJ: TStringField
      FieldName = 'CNPJ'
      Size = 14
    end
  end
  object Fornecedores: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 256
    Top = 705
  end
  object tPesquisa: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 328
    Top = 705
  end
  object tContainer: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 400
    Top = 705
  end
  object dsContainer: TDataSource
    DataSet = Container
    Left = 40
    Top = 740
  end
  object dsProcessosDOC: TDataSource
    DataSet = ProcessosDOC
    Left = 112
    Top = 740
  end
  object dsArmazens: TDataSource
    DataSet = Armazens
    Left = 184
    Top = 740
  end
  object dsFornecedores: TDataSource
    DataSet = Fornecedores
    Left = 256
    Top = 740
  end
end
