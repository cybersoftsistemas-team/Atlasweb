unit Container;

interface

uses
  Winapi.Windows, System.SysUtils, System.Classes, Data.DB,
  Vcl.Dialogs,
  FireDAC.Comp.Client, FireDAC.Comp.DataSet, FireDAC.Stan.Param,
  uniGUIBaseClasses, uniGUIClasses, uniGUIFrame, uniPanel, uniButton, uniSpeedButton, uniDBNavigator, uniSweetAlert,
  uniEdit, uniCheckBox, uniPageControl, uniDBGrid, uniScrollBox,
  uniDBEdit, uniDBMemo, uniDBLookupComboBox, uniDBDateTimePicker,
  uniDBComboBox, uniComboBox, uniLabel, uniBasicGrid,
  Funcoes;

type
  TfContainer = class(TUniFrame)
    Alerta: TUniSweetAlert;
    pBarraNav: TUniPanel;
    Navega: TUniDBNavigator;
    bAdicionar: TUniSpeedButton;
    bEditar: TUniSpeedButton;
    bExcluir: TUniSpeedButton;
    bGravar: TUniSpeedButton;
    bCancelar: TUniSpeedButton;
    bPesquisa: TUniSpeedButton;
    bSair: TUniSpeedButton;
    pBarraPesq: TUniPanel;
    cPesquisa: TUniEdit;
    cTravar: TUniCheckBox;
    Pasta: TUniPageControl;
    aLista: TUniTabSheet;
    Grade: TUniDBGrid;
    aFicha: TUniTabSheet;
    pFicha: TUniScrollBox;
    pFicha1: TUniPanel;
    cProcesso: TUniDBLookupComboBox;
    cNumero: TUniDBEdit;
    cTipoEmbarque: TUniDBComboBox;
    DBEdit13: TUniDBEdit;
    DBEdit9: TUniDBEdit;
    DBEdit10: TUniDBEdit;
    DBEdit11: TUniDBEdit;
    DBEdit1: TUniDBEdit;
    DBDateEdit3: TUniDBDateTimePicker;
    DBEdit4: TUniDBEdit;
    DBDateEdit1: TUniDBDateTimePicker;
    DBEdit6: TUniDBEdit;
    cFreeTime: TUniDBEdit;
    cValorDemurrage: TUniDBEdit;
    cTaxa: TUniDBEdit;
    cArmazem: TUniDBLookupComboBox;
    DBLookupComboBox3: TUniDBLookupComboBox;
    DBLookupComboBox4: TUniDBLookupComboBox;
    cDataEntrega: TUniDBDateTimePicker;
    DBEdit2: TUniDBEdit;
    DBDateEdit4: TUniDBDateTimePicker;
    DBMemo1: TUniDBMemo;
    cMemoProcessos: TUniDBMemo;
    cAdicionarProcesso: TUniComboBox;
    bAdicionarProcesso: TUniButton;
    cDemurrage: TUniEdit;
    cTotalME: TUniEdit;
    cTotalReal: TUniEdit;
    Container: TFDQuery;
    ProcessosDOC: TFDQuery;
    Armazens: TFDQuery;
    ArmazensCodigo: TIntegerField;
    ArmazensNome: TStringField;
    ArmazensCNPJ: TStringField;
    Fornecedores: TFDQuery;
    tPesquisa: TFDQuery;
    tContainer: TFDQuery;
    dsContainer: TDataSource;
    dsProcessosDOC: TDataSource;
    dsArmazens: TDataSource;
    dsFornecedores: TDataSource;
    procedure UniFrameCreate(Sender: TObject);
    procedure bSairClick(Sender: TObject);
    procedure bAdicionarClick(Sender: TObject);
    procedure bEditarClick(Sender: TObject);
    procedure bExcluirClick(Sender: TObject);
    procedure bGravarClick(Sender: TObject);
    procedure bCancelarClick(Sender: TObject);
    procedure bPesquisaClick(Sender: TObject);
    procedure cPesquisaKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure cFreeTimeExit(Sender: TObject);
    procedure DBEdit4Exit(Sender: TObject);
    procedure cProcessoChange(Sender: TObject);
    procedure cTravarClick(Sender: TObject);
    procedure cNumeroChange(Sender: TObject);
    procedure cNumeroExit(Sender: TObject);
    procedure cValorDemurrageChange(Sender: TObject);
    procedure cTipoEmbarqueExit(Sender: TObject);
    procedure bAdicionarProcessoClick(Sender: TObject);
    procedure cDataEntregaExit(Sender: TObject);
    procedure ContainerAfterScroll(DataSet: TDataSet);
    procedure ContainerBeforePost(DataSet: TDataSet);
  private
    procedure LigaBotoes(Estado: Boolean);
    procedure CalculaDemurrage;
    procedure CarregaProcessosAdicionais;
    procedure AtualizaTipoEmbarque;
  public
    mProcesso: String;
    mConhecimento: String;
    procedure AbrirDados;
  end;

implementation

uses MainModule, Main;

{$R *.dfm}

procedure TfContainer.UniFrameCreate(Sender: TObject);
begin
     LigaBotoes(True);
     Pasta.ActivePage := aLista;
     AbrirDados;
end;

procedure TfContainer.AbrirDados;
begin
     with Container do begin
          Close;
          SQL.Clear;
          SQL.Add('SELECT * FROM Container ORDER BY Processo, Numero');
          Open;
     end;
     with ProcessosDOC do begin
          Close;
          SQL.Clear;
          SQL.Add('SELECT * FROM ProcessosDocumentos ORDER BY Processo');
          Open;
     end;
     with Armazens do begin
          Close;
          SQL.Clear;
          SQL.Add('SELECT * FROM Fornecedores');
          SQL.Add('WHERE (SELECT Modulo_Container FROM RamoAtividade');
          SQL.Add('WHERE (Codigo = Ramo_Atividade) AND (Descricao LIKE ''%ARM%'')) = 1');
          SQL.Add('ORDER BY Nome');
          Open;
     end;
     with Fornecedores do begin
          Close;
          SQL.Clear;
          SQL.Add('SELECT * FROM Fornecedores');
          SQL.Add('WHERE (SELECT Modulo_Container FROM RamoAtividade');
          SQL.Add('WHERE (Codigo = Ramo_Atividade) AND (Descricao LIKE ''%TRANS%'')) = 1');
          SQL.Add('ORDER BY Nome');
          Open;
     end;
     if Trim(mProcesso) <> '' then begin
        Container.Locate('Processo', mProcesso, [loCaseInsensitive]);
        cProcesso.Enabled := False;
     end;
     CarregaProcessosAdicionais;
     CalculaDemurrage;
end;

procedure TfContainer.LigaBotoes(Estado: Boolean);
begin
     bAdicionar.Enabled := Estado;
     bEditar.Enabled := Estado;
     bExcluir.Enabled := Estado;
     bGravar.Enabled := not Estado;
     bCancelar.Enabled := not Estado;
     bPesquisa.Enabled := Estado;
     Navega.Enabled := Estado;
     aLista.TabVisible := Estado;
     if Estado then Pasta.ActivePage := aLista else Pasta.ActivePage := aFicha;
     AtualizaTipoEmbarque;
end;

procedure TfContainer.bSairClick(Sender: TObject);
begin
     MainForm.PagePrincipal.Pages[MainForm.PagePrincipal.ActivePageIndex].Free;
end;

procedure TfContainer.bAdicionarClick(Sender: TObject);
var
  Origem: TFDQuery;
begin
     Origem := TFDQuery.Create(nil);
     try
        Origem.Connection := UniMainModule.Conecta;
        if cTravar.Checked and (not Container.IsEmpty) then begin
           Origem.SQL.Clear;
           Origem.SQL.Add('SELECT * FROM Container WHERE Numero = :pNumero');
           Origem.ParamByName('pNumero').AsString := Container.FieldByName('Numero').AsString;
           Origem.Open;
        end;
        Container.Append;
        if Trim(mProcesso) <> '' then Container.FieldByName('Processo').AsString := mProcesso;
        if Trim(mConhecimento) <> '' then Container.FieldByName('Documento_Carga').AsString := mConhecimento;
        if cTravar.Checked and Origem.Active and (not Origem.IsEmpty) then begin
           // Copia os mesmos campos da rotina Desktop, sem sobrescrever a chave do registro.
           Container.FieldByName('Hora_Entrada').Value := Origem.FieldByName('Hora_Entrada').Value;
           Container.FieldByName('Hora_Saida').Value := Origem.FieldByName('Hora_Saida').Value;
           Container.FieldByName('Data_Entrada').Value := Origem.FieldByName('Data_Entrada').Value;
           Container.FieldByName('Data_Saida').Value := Origem.FieldByName('Data_Saida').Value;
           Container.FieldByName('Data_Entrega').Value := Origem.FieldByName('Data_Entrega').Value;
           Container.FieldByName('Armazem').Value := Origem.FieldByName('Armazem').Value;
           Container.FieldByName('Valor_Demurrage').Value := Origem.FieldByName('Valor_Demurrage').Value;
           Container.FieldByName('Transportadora_Saida').Value := Origem.FieldByName('Transportadora_Saida').Value;
           Container.FieldByName('Free_Time').Value := Origem.FieldByName('Free_Time').Value;
           Container.FieldByName('Tamanho').Value := Origem.FieldByName('Tamanho').Value;
           Container.FieldByName('Transportadora_Entrada').Value := Origem.FieldByName('Transportadora_Entrada').Value;
           Container.FieldByName('Observacao').Value := Origem.FieldByName('Observacao').Value;
           Container.FieldByName('Hora_Entrega').Value := Origem.FieldByName('Hora_Entrega').Value;
           Container.FieldByName('Armador').Value := Origem.FieldByName('Armador').Value;
           Container.FieldByName('Documento_Carga').Value := Origem.FieldByName('Documento_Carga').Value;
           Container.FieldByName('Terminal').Value := Origem.FieldByName('Terminal').Value;
           Container.FieldByName('Processo').Value := Origem.FieldByName('Processo').Value;
           Container.FieldByName('Tipo').Value := Origem.FieldByName('Tipo').Value;
        end;
        LigaBotoes(False);
     finally
        Origem.Free;
     end;
end;

procedure TfContainer.bEditarClick(Sender: TObject);
begin
     if Container.IsEmpty then Exit;
     Container.Edit;
     LigaBotoes(False);
end;

procedure TfContainer.bExcluirClick(Sender: TObject);
begin
     if Container.IsEmpty then Exit;
     MessageDlg('Deseja realmente excluir o container ' + Container.FieldByName('Numero').AsString + '?', mtConfirmation, mbYesNo,
                procedure(Comp: TComponent; ARes: Integer)
                begin
                     if ARes = mrYes then begin
                        Container.Delete;
                        Alerta.Text := 'Registro exclu�do do banco de dados!';
                        Alerta.Execute;
                     end;
                end);
end;

procedure TfContainer.ContainerBeforePost(DataSet: TDataSet);
begin
     if DataSet.State = dsInsert then begin
        with tPesquisa do begin
             Close;
             SQL.Clear;
             SQL.Add('SELECT COUNT(*) AS Qtde FROM Container');
             SQL.Add('WHERE (Numero = :pNumero) AND (Processo = :pProcesso)');
             ParamByName('pNumero').AsString := DataSet.FieldByName('Numero').AsString;
             ParamByName('pProcesso').AsString := DataSet.FieldByName('Processo').AsString;
             Open;
             if FieldByName('Qtde').AsInteger > 0 then begin
                MessageDlg('N�mero de Container j� cadastrado!', mtError, [mbOK]);
                cNumero.SetFocus;
                Abort;
             end;
        end;
     end;
     if Trim(DataSet.FieldByName('Tipo_Embarque').AsString) = '' then begin
        MessageDlg('"Tipo de Embarque" � campo obrigat�rio!', mtError, [mbOK]);
        cTipoEmbarque.SetFocus;
        Abort;
     end;
end;

procedure TfContainer.bGravarClick(Sender: TObject);
begin
     try
        if Container.State in [dsInsert, dsEdit] then Container.Post;
        LigaBotoes(True);
        CalculaDemurrage;
     except
        on E: Exception do MessageDlg('Falha ao gravar container: ' + E.Message, mtError, [mbOK]);
     end;
end;

procedure TfContainer.bCancelarClick(Sender: TObject);
begin
     Container.Cancel;
     LigaBotoes(True);
end;

procedure TfContainer.bPesquisaClick(Sender: TObject);
var
  mPesquisa: String;
begin
     mPesquisa := UpperCase(Trim(cPesquisa.Text));
     if mPesquisa = '' then Exit;
     if not Container.Locate('Numero', mPesquisa, [loPartialKey, loCaseInsensitive]) then
        if not Container.Locate('Processo', mPesquisa, [loPartialKey, loCaseInsensitive]) then begin
           with tPesquisa do begin
                Close;
                SQL.Clear;
                SQL.Add('SELECT TOP 1 Numero FROM Container WHERE Documento_Carga LIKE :pPesquisa');
                ParamByName('pPesquisa').AsString := '%' + mPesquisa + '%';
                Open;
                if IsEmpty then
                   MessageDlg('Nenhum registro encontrado com n�mero de Container ou Documento de Carga informado!', mtInformation, [mbOK])
                else
                   Container.Locate('Numero', FieldByName('Numero').AsString, [loCaseInsensitive]);
           end;
        end;
     CalculaDemurrage;
end;

procedure TfContainer.cPesquisaKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
     if Key = VK_RETURN then bPesquisaClick(Sender);
end;

procedure TfContainer.cFreeTimeExit(Sender: TObject);
begin
     if Container.State in [dsInsert, dsEdit] then
        if not Container.FieldByName('Data_Entrada').IsNull then
           Container.FieldByName('Data_Saida').AsDateTime :=
             Container.FieldByName('Data_Entrada').AsDateTime + Container.FieldByName('Free_Time').AsInteger;
end;

procedure TfContainer.DBEdit4Exit(Sender: TObject);
begin
     if Container.State in [dsInsert, dsEdit] then
        if Trim(Container.FieldByName('Hora_Saida').AsString) = '' then
           Container.FieldByName('Hora_Saida').AsString := Container.FieldByName('Hora_Entrada').AsString;
end;

procedure TfContainer.cDataEntregaExit(Sender: TObject);
begin
     CalculaDemurrage;
end;

procedure TfContainer.cProcessoChange(Sender: TObject);
begin
     if not (Container.State in [dsInsert, dsEdit]) or ProcessosDOC.IsEmpty then Exit;
     if not ProcessosDOC.Locate('Processo', cProcesso.KeyValue, []) then Exit;
     Container.FieldByName('Numero').AsString := ProcessosDOC.FieldByName('Container_Numero').AsString;
     Container.FieldByName('Armador').AsString := ProcessosDOC.FieldByName('Agencia_Maritima').AsString;
     Container.FieldByName('Documento_Carga').AsString := ProcessosDOC.FieldByName('Numero_DOC').AsString;
     AtualizaTipoEmbarque;
end;

procedure TfContainer.cTravarClick(Sender: TObject);
begin
     if Container.IsEmpty then Exit;
     with tContainer do begin
          Close;
          SQL.Clear;
          SQL.Add('SELECT * FROM Container WHERE Numero = :pNumero');
          ParamByName('pNumero').AsString := Container.FieldByName('Numero').AsString;
          Open;
     end;
end;

procedure TfContainer.cNumeroChange(Sender: TObject);
begin
     if not (Container.State in [dsInsert, dsEdit]) then cTravar.Checked := False;
end;

procedure TfContainer.cNumeroExit(Sender: TObject);
begin
     if (Trim(cNumero.Text) <> '') and (not VerificaContainer(Trim(cNumero.Text))) then
        MessageDlg('N�mero do container incorreto!', mtError, [mbOK]);
end;

procedure TfContainer.CalculaDemurrage;
var
  Dias: Integer;
  Valor: Currency;
  Taxa: Double;
begin
     if not Container.Active or Container.IsEmpty then Exit;
     if Container.FieldByName('Data_Saida').IsNull then Exit;
     if Container.FieldByName('Data_Entrega').IsNull then
        Dias := Trunc(Date) - Trunc(Container.FieldByName('Data_Saida').AsDateTime)
     else
        Dias := Trunc(Container.FieldByName('Data_Entrega').AsDateTime) - Trunc(Container.FieldByName('Data_Saida').AsDateTime);
     if Container.State in [dsInsert, dsEdit] then
        if Container.FieldByName('Taxa').AsFloat = 0 then
           if ProcessosDOC.Active and not ProcessosDOC.IsEmpty then
              Container.FieldByName('Taxa').AsFloat := ProcessosDOC.FieldByName('Taxa_FOB').AsFloat;
     Valor := Container.FieldByName('Valor_Demurrage').AsCurrency;
     Taxa := Container.FieldByName('Taxa').AsFloat;
     cDemurrage.Text := IntToStr(Dias);
     cTotalME.Text := FormatFloat('#,##0.00', Valor * Dias);
     cTotalReal.Text := FormatFloat('#,##0.00', Valor * Dias * Taxa);
end;

procedure TfContainer.cValorDemurrageChange(Sender: TObject);
begin
     CalculaDemurrage;
end;

procedure TfContainer.AtualizaTipoEmbarque;
var
  Estado: Boolean;
begin
     Estado := UpperCase(cTipoEmbarque.Text) = 'LCL - INTEGRAL';
     bAdicionarProcesso.Enabled := Estado and (Container.State in [dsInsert, dsEdit]);
     cAdicionarProcesso.Enabled := Estado and (Container.State in [dsInsert, dsEdit]);
     cMemoProcessos.Enabled := Estado and (Container.State in [dsInsert, dsEdit]);
end;

procedure TfContainer.cTipoEmbarqueExit(Sender: TObject);
begin
     AtualizaTipoEmbarque;
end;

procedure TfContainer.CarregaProcessosAdicionais;
begin
     cAdicionarProcesso.Items.Clear;
     if not ProcessosDOC.Active then Exit;
     ProcessosDOC.First;
     while not ProcessosDOC.Eof do begin
        cAdicionarProcesso.Items.Add(ProcessosDOC.FieldByName('Processo').AsString);
        ProcessosDOC.Next;
     end;
     ProcessosDOC.First;
end;

procedure TfContainer.bAdicionarProcessoClick(Sender: TObject);
begin
     if Trim(cAdicionarProcesso.Text) = '' then Exit;
     if not (Container.State in [dsInsert, dsEdit]) then Exit;
     Container.FieldByName('Memo_Processos').AsString :=
       Container.FieldByName('Memo_Processos').AsString + cAdicionarProcesso.Text + ', ';
     cAdicionarProcesso.ItemIndex := -1;
end;

procedure TfContainer.ContainerAfterScroll(DataSet: TDataSet);
begin
     if not (Container.State in [dsInsert, dsEdit]) then CalculaDemurrage;
end;

end.
