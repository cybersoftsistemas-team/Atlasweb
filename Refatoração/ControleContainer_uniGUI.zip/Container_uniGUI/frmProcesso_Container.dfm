object fProcesso_Container: TfProcesso_Container
  Left = 0
  Top = 0
  Width = 1190
  Height = 790
  OnCreate = UniFrameCreate
  TabOrder = 0
  object pBarraNav: TUniPanel
    Left = 0
    Top = 0
    Width = 1190
    Height = 42
    Align = alTop
    Caption = ''
    TabOrder = 0
    object bAdicionar: TUniButton
      Left = 8
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Adicionar'
      TabOrder = 0
      OnClick = bAdicionarClick
    end
    object bEditar: TUniButton
      Left = 108
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Editar'
      TabOrder = 1
      OnClick = bEditarClick
    end
    object bExcluir: TUniButton
      Left = 208
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Excluir'
      TabOrder = 2
      OnClick = bExcluirClick
    end
    object bGravar: TUniButton
      Left = 308
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Gravar'
      TabOrder = 3
      OnClick = bGravarClick
    end
    object bCancelar: TUniButton
      Left = 408
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Cancelar'
      TabOrder = 4
      OnClick = bCancelarClick
    end
    object bPesquisa: TUniButton
      Left = 508
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Pesquisar'
      TabOrder = 5
      OnClick = bPesquisaClick
    end
    object bSair: TUniButton
      Left = 608
      Top = 6
      Width = 94
      Height = 28
      Caption = 'Fechar'
      TabOrder = 6
      OnClick = bSairClick
    end
    object bPrimeiro: TUniButton
      Left = 708
      Top = 6
      Width = 94
      Height = 28
      Caption = '|<'
      TabOrder = 7
      OnClick = bPrimeiroClick
    end
    object bAnterior: TUniButton
      Left = 808
      Top = 6
      Width = 94
      Height = 28
      Caption = '<'
      TabOrder = 8
      OnClick = bAnteriorClick
    end
    object bProximo: TUniButton
      Left = 908
      Top = 6
      Width = 94
      Height = 28
      Caption = '>'
      TabOrder = 9
      OnClick = bProximoClick
    end
    object bUltimo: TUniButton
      Left = 1008
      Top = 6
      Width = 94
      Height = 28
      Caption = '>|'
      TabOrder = 10
      OnClick = bUltimoClick
    end
  end
  object pBarraPesq: TUniPanel
    Left = 0
    Top = 42
    Width = 1190
    Height = 40
    Align = alTop
    Caption = ''
    TabOrder = 1
    object cPesquisa: TUniEdit
      Left = 12
      Top = 7
      Width = 310
      Height = 26
      EmptyText = 'Container / Processo / Documento de carga'
      TabOrder = 0
      OnKeyDown = cPesquisaKeyDown
    end
    object cTravar: TUniCheckBox
      Left = 350
      Top = 10
      Width = 270
      Height = 22
      Caption = 'Copiar dados do container anterior'
      TabOrder = 1
      OnClick = cTravarClick
    end
  end
  object Pasta: TUniPageControl
    Left = 0
    Top = 82
    Width = 1190
    Height = 708
    Align = alClient
    ActivePage = aLista
    TabOrder = 2
    object aLista: TUniTabSheet
      Caption = 'Lista'
      object Grade: TUniDBGrid
        Left = 0
        Top = 0
        Width = 1182
        Height = 670
        Align = alClient
        DataSource = dsContainer
        ReadOnly = True
        TabOrder = 0
      end
    end
    object aFicha: TUniTabSheet
      Caption = 'Ficha'
      object pFicha: TUniScrollBox
        Left = 0
        Top = 0
        Width = 1182
        Height = 670
        Align = alClient
        TabOrder = 0
        object lbl0: TUniLabel
          Left = 14
          Top = 18
          Caption = 'Processo'
        end
        object cProcesso: TUniDBLookupComboBox
          Left = 14
          Top = 38
          Width = 180
          Height = 28
          DataField = 'Processo'
          DataSource = dsContainer
          TabOrder = 0
          ListSource = dsProcessosDOC
          KeyField = 'Processo'
          ListField = 'Processo'
          OnChange = cProcessoChange
        end
        object lbl1: TUniLabel
          Left = 14
          Top = 84
          Caption = 'N� container'
        end
        object cNumero: TUniDBEdit
          Left = 14
          Top = 104
          Width = 180
          Height = 28
          DataField = 'Numero'
          DataSource = dsContainer
          TabOrder = 1
          OnChange = cNumeroChange
          OnExit = cNumeroExit
        end
        object lbl2: TUniLabel
          Left = 14
          Top = 150
          Caption = 'Tipo embarque'
        end
        object cTipoEmbarque: TUniDBComboBox
          Left = 14
          Top = 170
          Width = 180
          Height = 28
          DataField = 'Tipo_Embarque'
          DataSource = dsContainer
          TabOrder = 2
          Items.Strings = (
            'A�REO'
            'FCL'
            'LCL - INTEGRAL'
            'LCL - PARTE'
            'MAR�TIMO'
            'OUTROS')
          OnExit = cTipoEmbarqueExit
        end
        object lbl3: TUniLabel
          Left = 14
          Top = 216
          Caption = 'Documento carga'
        end
        object DBEdit13: TUniDBEdit
          Left = 14
          Top = 236
          Width = 180
          Height = 28
          DataField = 'Documento_Carga'
          DataSource = dsContainer
          TabOrder = 3
        end
        object lbl4: TUniLabel
          Left = 14
          Top = 282
          Caption = 'Tipo'
        end
        object DBEdit9: TUniDBEdit
          Left = 14
          Top = 302
          Width = 180
          Height = 28
          DataField = 'Tipo'
          DataSource = dsContainer
          TabOrder = 4
        end
        object lbl5: TUniLabel
          Left = 14
          Top = 348
          Caption = 'Tamanho'
        end
        object DBEdit10: TUniDBEdit
          Left = 14
          Top = 368
          Width = 180
          Height = 28
          DataField = 'Tamanho'
          DataSource = dsContainer
          TabOrder = 5
        end
        object lbl6: TUniLabel
          Left = 14
          Top = 414
          Caption = 'Armador'
        end
        object DBEdit11: TUniDBEdit
          Left = 14
          Top = 434
          Width = 180
          Height = 28
          DataField = 'Armador'
          DataSource = dsContainer
          TabOrder = 6
        end
        object lbl7: TUniLabel
          Left = 14
          Top = 480
          Caption = 'Terminal'
        end
        object DBEdit1: TUniDBEdit
          Left = 14
          Top = 500
          Width = 180
          Height = 28
          DataField = 'Terminal'
          DataSource = dsContainer
          TabOrder = 7
        end
        object lbl8: TUniLabel
          Left = 405
          Top = 18
          Caption = 'Data entrada'
        end
        object DBDateEdit3: TUniDBDateTimePicker
          Left = 405
          Top = 38
          Width = 180
          Height = 28
          DataField = 'Data_Entrada'
          DataSource = dsContainer
          TabOrder = 8
          OnExit = cFreeTimeExit
        end
        object lbl9: TUniLabel
          Left = 405
          Top = 84
          Caption = 'Hora entrada'
        end
        object DBEdit4: TUniDBEdit
          Left = 405
          Top = 104
          Width = 180
          Height = 28
          DataField = 'Hora_Entrada'
          DataSource = dsContainer
          TabOrder = 9
          OnExit = DBEdit4Exit
        end
        object lbl10: TUniLabel
          Left = 405
          Top = 150
          Caption = 'Data sa�da'
        end
        object DBDateEdit1: TUniDBDateTimePicker
          Left = 405
          Top = 170
          Width = 180
          Height = 28
          DataField = 'Data_Saida'
          DataSource = dsContainer
          TabOrder = 10
        end
        object lbl11: TUniLabel
          Left = 405
          Top = 216
          Caption = 'Hora sa�da'
        end
        object DBEdit6: TUniDBEdit
          Left = 405
          Top = 236
          Width = 180
          Height = 28
          DataField = 'Hora_Saida'
          DataSource = dsContainer
          TabOrder = 11
        end
        object lbl12: TUniLabel
          Left = 405
          Top = 282
          Caption = 'Free time'
        end
        object cFreeTime: TUniDBEdit
          Left = 405
          Top = 302
          Width = 180
          Height = 28
          DataField = 'Free_Time'
          DataSource = dsContainer
          TabOrder = 12
          OnExit = cFreeTimeExit
        end
        object lbl13: TUniLabel
          Left = 405
          Top = 348
          Caption = 'Valor demurrage'
        end
        object cValorDemurrage: TUniDBEdit
          Left = 405
          Top = 368
          Width = 180
          Height = 28
          DataField = 'Valor_Demurrage'
          DataSource = dsContainer
          TabOrder = 13
          OnChange = cValorDemurrageChange
        end
        object lbl14: TUniLabel
          Left = 405
          Top = 414
          Caption = 'Taxa'
        end
        object cTaxa: TUniDBEdit
          Left = 405
          Top = 434
          Width = 180
          Height = 28
          DataField = 'Taxa'
          DataSource = dsContainer
          TabOrder = 14
          OnChange = cValorDemurrageChange
        end
        object lbl15: TUniLabel
          Left = 800
          Top = 18
          Caption = 'Armaz�m'
        end
        object cArmazem: TUniDBLookupComboBox
          Left = 800
          Top = 38
          Width = 230
          Height = 28
          DataField = 'Armazem'
          DataSource = dsContainer
          TabOrder = 15
          ListSource = dsArmazens
          KeyField = 'Codigo'
          ListField = 'Nome'
        end
        object lbl16: TUniLabel
          Left = 800
          Top = 84
          Caption = 'Transportadora entrada'
        end
        object DBLookupComboBox3: TUniDBLookupComboBox
          Left = 800
          Top = 104
          Width = 230
          Height = 28
          DataField = 'Transportadora_Entrada'
          DataSource = dsContainer
          TabOrder = 16
          ListSource = dsFornecedores
          KeyField = 'Codigo'
          ListField = 'Nome'
        end
        object lbl17: TUniLabel
          Left = 800
          Top = 150
          Caption = 'Transportadora sa�da'
        end
        object DBLookupComboBox4: TUniDBLookupComboBox
          Left = 800
          Top = 170
          Width = 230
          Height = 28
          DataField = 'Transportadora_Saida'
          DataSource = dsContainer
          TabOrder = 17
          ListSource = dsFornecedores
          KeyField = 'Codigo'
          ListField = 'Nome'
        end
        object lbl18: TUniLabel
          Left = 800
          Top = 216
          Caption = 'Data entrega'
        end
        object cDataEntrega: TUniDBDateTimePicker
          Left = 800
          Top = 236
          Width = 230
          Height = 28
          DataField = 'Data_Entrega'
          DataSource = dsContainer
          TabOrder = 18
          OnExit = cDataEntregaExit
        end
        object lbl19: TUniLabel
          Left = 800
          Top = 282
          Caption = 'Hora entrega'
        end
        object DBEdit2: TUniDBEdit
          Left = 800
          Top = 302
          Width = 230
          Height = 28
          DataField = 'Hora_Entrega'
          DataSource = dsContainer
          TabOrder = 19
        end
        object lbl20: TUniLabel
          Left = 800
          Top = 348
          Caption = 'Data pagamento'
        end
        object DBDateEdit4: TUniDBDateTimePicker
          Left = 800
          Top = 368
          Width = 230
          Height = 28
          DataField = 'Data_Pagamento'
          DataSource = dsContainer
          TabOrder = 20
        end
        object DBMemo1: TUniDBMemo
          Left = 14
          Top = 550
          Width = 385
          Height = 84
          DataField = 'Observacao'
          DataSource = dsContainer
          TabOrder = 21
        end
        object cMemoProcessos: TUniDBMemo
          Left = 434
          Top = 550
          Width = 385
          Height = 84
          DataField = 'Memo_Processos'
          DataSource = dsContainer
          TabOrder = 22
        end
        object cAdicionarProcesso: TUniComboBox
          Left = 820
          Top = 558
          Width = 200
          Height = 28
          TabOrder = 25
        end
        object bAdicionarProcesso: TUniButton
          Left = 1030
          Top = 558
          Width = 115
          Height = 28
          Caption = 'Adicionar processo'
          TabOrder = 26
          OnClick = bAdicionarProcessoClick
        end
        object cDemurrage: TUniEdit
          Left = 14
          Top = 645
          Width = 170
          Height = 26
          ReadOnly = True
          TabOrder = 27
        end
        object cTotalME: TUniEdit
          Left = 404
          Top = 645
          Width = 170
          Height = 26
          ReadOnly = True
          TabOrder = 28
        end
        object cTotalReal: TUniEdit
          Left = 794
          Top = 645
          Width = 170
          Height = 26
          ReadOnly = True
          TabOrder = 29
        end
      end
    end
  end
  object Container: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 40
    Top = 705
    OnAfterScroll = ContainerAfterScroll
    OnBeforePost = ContainerBeforePost
  end
  object ProcessosDOC: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 112
    Top = 705
  end
  object Armazens: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 184
    Top = 705
    object ArmazensCodigo: TIntegerField
      FieldName = 'Codigo'
    end
    object ArmazensNome: TStringField
      FieldName = 'Nome'
      Size = 60
    end
    object ArmazensCNPJ: TStringField
      FieldName = 'CNPJ'
      Size = 14
    end
  end
  object Fornecedores: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 256
    Top = 705
  end
  object tPesquisa: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 328
    Top = 705
  end
  object tContainer: TFDQuery
    Connection = UniMainModule.Conecta
    Left = 400
    Top = 705
  end
  object dsContainer: TDataSource
    DataSet = Container
    Left = 40
    Top = 740
  end
  object dsProcessosDOC: TDataSource
    DataSet = ProcessosDOC
    Left = 112
    Top = 740
  end
  object dsArmazens: TDataSource
    DataSet = Armazens
    Left = 184
    Top = 740
  end
  object dsFornecedores: TDataSource
    DataSet = Fornecedores
    Left = 256
    Top = 740
  end
end
