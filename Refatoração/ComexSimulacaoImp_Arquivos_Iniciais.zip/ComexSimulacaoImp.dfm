object fProcesso_SimulacaoCalculo: TfComexSimulacaoImp
  Left = 0
  Top = 0
  Width = 1000
  Height = 780
  OnCreate = UniFrameCreate
  OnDestroy = UniFrameDestroy
  object RxLabel3: TUniLabel
    Left = 8
    Top = 3
    Width = 76
    Height = 21
    Caption = 'PROCESSO'
    Font.Color = clWhite
    Font.Height = -17
    Font.Name = 'Calibri'
    Font.Style = [fsBold, fsItalic]
    ParentFont = False
  end
  object RxLabel4: TUniLabel
    Left = 8
    Top = 22
    Width = 229
    Height = 18
    Caption = 'Simula'#231#227'o de c'#225'lculo de importa'#231#227'o.'
    Font.Color = clWhite
    Font.Height = -15
    Font.Name = 'Calibri'
    Font.Style = [fsBold, fsItalic]
    ParentFont = False
  end
  object PageControl1: TUniPageControl
    Left = 3
    Top = 49
    Width = 801
    Height = 629
    Align = alClient
    TabOrder = 0
    object TabSheet1: TUniTabSheet
      Caption = 'Dados da &Importa'#231#227'o'
      object Panel5: TUniPanel
        Left = 3
        Top = 3
        Width = 787
        Height = 588
        Align = alClient
        Enabled = False
        TabOrder = 0
        object Label3: TUniLabel
          Left = 574
          Top = 335
          Width = 89
          Height = 13
          Caption = 'Aliquota_IRPJServ'
        end
        object StaticText44: TUniLabel
          Left = 4
          Top = 51
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Modalidade Importa'#231#227'o'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 0
        end
        object lData: TUniLabel
          Left = 200
          Top = 5
          Width = 33
          Height = 21
          AutoSize = False
          Caption = 'Data'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 42
        end
        object StaticText3: TUniLabel
          Left = 4
          Top = 143
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Fornecedor'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 43
        end
        object StaticText5: TUniLabel
          Left = 4
          Top = 166
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Pa'#237's Origem'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 44
        end
        object StaticText8: TUniLabel
          Left = 478
          Top = 281
          Width = 81
          Height = 21
          AutoSize = False
          Caption = 'Valor FOB (ME)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 45
        end
        object cNumero: TUniDBEdit
          Left = 124
          Top = 5
          Width = 73
          Height = 21
          DataField = 'Numero'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 1
        end
        object DBEdit5: TUniDBEdit
          Left = 124
          Top = 143
          Width = 385
          Height = 21
          DataField = 'Fornecedor'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 11
        end
        object DBEdit11: TUniDBEdit
          Left = 561
          Top = 281
          Width = 95
          Height = 21
          DataField = 'FOB'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 23
        end
        object DBEdit17: TUniDBEdit
          Left = 124
          Top = 212
          Width = 263
          Height = 21
          DataField = 'Porto_Destino'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 16
        end
        object StaticText11: TUniLabel
          Left = 4
          Top = 5
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'N'#250'mero'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 46
        end
        object StaticText14: TUniLabel
          Left = 4
          Top = 235
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Modalidade Frete'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 47
        end
        object StaticText15: TUniLabel
          Left = 4
          Top = 212
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Porto Destino'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 48
        end
        object DBEdit18: TUniDBEdit
          Left = 124
          Top = 258
          Width = 74
          Height = 21
          DataField = 'Qtde_Container'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 19
        end
        object DBEdit20: TUniDBEdit
          Left = 561
          Top = 304
          Width = 95
          Height = 21
          DataField = 'Frete_Internacional'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 27
        end
        object cTaxaMoeda: TUniDBEdit
          Left = 410
          Top = 281
          Width = 66
          Height = 21
          DataField = 'Taxa_FOB'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 22
        end
        object DBEdit24: TUniDBEdit
          Left = 685
          Top = 281
          Width = 94
          Height = 21
          Color = 16766421
          DataField = 'FOB_Real'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 24
        end
        object DBEdit25: TUniDBEdit
          Left = 685
          Top = 304
          Width = 94
          Height = 21
          Color = 16766421
          DataField = 'Frete_Real'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 28
        end
        object StaticText16: TUniLabel
          Left = 4
          Top = 258
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Qtde.Containers'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 49
        end
        object StaticText18: TUniLabel
          Left = 478
          Top = 304
          Width = 81
          Height = 21
          AutoSize = False
          Caption = 'Frete (ME)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 50
        end
        object StaticText21: TUniLabel
          Left = 374
          Top = 281
          Width = 34
          Height = 21
          AutoSize = False
          Caption = 'Taxa'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 51
        end
        object StaticText22: TUniLabel
          Left = 658
          Top = 281
          Width = 25
          Height = 21
          AutoSize = False
          Caption = 'R$'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 52
        end
        object StaticText23: TUniLabel
          Left = 658
          Top = 304
          Width = 25
          Height = 21
          AutoSize = False
          Caption = 'R$'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 53
        end
        object DBEdit32: TUniDBEdit
          Left = 349
          Top = 373
          Width = 97
          Height = 21
          DataField = 'Taxa_Adiministrativa'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 32
        end
        object StaticText29: TUniLabel
          Left = 229
          Top = 373
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Taxa Administrativa'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 54
        end
        object cDataRegistro_DI: TUniDBDateTimePicker
          Left = 235
          Top = 5
          Width = 152
          Height = 21
          DataField = 'Data'
          Font.Color = clBlack
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
        end
        object StaticText31: TUniLabel
          Left = 390
          Top = 51
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Beneficio'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 55
        end
        object StaticText32: TUniLabel
          Left = 4
          Top = 281
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Moeda FOB'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 56
        end
        object RxDBLookupCombo1: TUniDBLookupComboBox
          Left = 124
          Top = 281
          Width = 247
          Height = 21
          DataField = 'Moeda_FOB'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 21
        end
        object RxDBLookupCombo2: TUniDBLookupComboBox
          Left = 510
          Top = 51
          Width = 268
          Height = 21
          DataField = 'Beneficio'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 7
        end
        object StaticText39: TUniLabel
          Left = 4
          Top = 396
          Width = 117
          Height = 21
          AutoSize = False
          Caption = 'IRPJ'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 57
        end
        object DBEdit1: TUniDBEdit
          Left = 123
          Top = 396
          Width = 50
          Height = 21
          DataField = 'Aliquota_IRPJ'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 33
        end
        object StaticText40: TUniLabel
          Left = 264
          Top = 396
          Width = 42
          Height = 21
          AutoSize = False
          Caption = 'CSLL'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 58
        end
        object DBEdit2: TUniDBEdit
          Left = 308
          Top = 396
          Width = 50
          Height = 21
          DataField = 'Aliquota_CSLL'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 35
        end
        object DBEdit4: TUniDBEdit
          Left = 175
          Top = 396
          Width = 86
          Height = 21
          DataField = 'Valor_IRPJ'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 34
        end
        object DBEdit8: TUniDBEdit
          Left = 360
          Top = 396
          Width = 86
          Height = 21
          DataField = 'Valor_CSLL'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 36
        end
        object DBEdit28: TUniDBEdit
          Left = 124
          Top = 350
          Width = 100
          Height = 21
          DataField = 'Peso_Liquido'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 29
        end
        object DBEdit29: TUniDBEdit
          Left = 349
          Top = 350
          Width = 97
          Height = 21
          DataField = 'Peso_Bruto'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 30
        end
        object StaticText43: TUniLabel
          Left = 4
          Top = 350
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Peso L'#237'quido'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 59
        end
        object StaticText45: TUniLabel
          Left = 229
          Top = 350
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Peso Bruto'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 60
        end
        object cVia: TUniDBComboBox
          Left = 124
          Top = 235
          Width = 264
          Height = 21
          DataField = 'Modalidade_Frete'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 18
        end
        object RxDBLookupCombo3: TUniDBLookupComboBox
          Left = 124
          Top = 166
          Width = 263
          Height = 21
          DataField = 'Pais_Origem'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 12
        end
        object StaticText47: TUniLabel
          Left = 4
          Top = 189
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Pa'#237's Destino'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 61
        end
        object RxDBLookupCombo4: TUniDBLookupComboBox
          Left = 124
          Top = 189
          Width = 263
          Height = 21
          DataField = 'Pais_Destino'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 14
        end
        object StaticText48: TUniLabel
          Left = 390
          Top = 166
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Cidade Origem'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 62
        end
        object StaticText49: TUniLabel
          Left = 390
          Top = 189
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Cidade Destino'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 63
        end
        object DBEdit7: TUniDBEdit
          Left = 510
          Top = 166
          Width = 268
          Height = 21
          DataField = 'Cidade_Origem'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 13
        end
        object DBEdit16: TUniDBEdit
          Left = 510
          Top = 189
          Width = 268
          Height = 21
          DataField = 'Cidade_Destino'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 15
        end
        object StaticText50: TUniLabel
          Left = 390
          Top = 212
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Porto Origem'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 64
        end
        object DBEdit36: TUniDBEdit
          Left = 510
          Top = 212
          Width = 268
          Height = 21
          DataField = 'Porto_Origem'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 17
        end
        object StaticText51: TUniLabel
          Left = 4
          Top = 304
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Moeda Frete'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 65
        end
        object RxDBLookupCombo5: TUniDBLookupComboBox
          Left = 124
          Top = 304
          Width = 247
          Height = 21
          DataField = 'Moeda_Frete'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 25
        end
        object StaticText52: TUniLabel
          Left = 374
          Top = 304
          Width = 34
          Height = 21
          AutoSize = False
          Caption = 'Taxa'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 66
        end
        object DBEdit37: TUniDBEdit
          Left = 410
          Top = 304
          Width = 66
          Height = 21
          DataField = 'Taxa_Frete'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 26
        end
        object DBComboBox1: TUniDBComboBox
          Left = 280
          Top = 258
          Width = 197
          Height = 21
          DataField = 'Tipo_Container'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 20
        end
        object StaticText10: TUniLabel
          Left = 199
          Top = 258
          Width = 79
          Height = 21
          AutoSize = False
          Caption = 'Tipo Container'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 67
        end
        object StaticText27: TUniLabel
          Left = 4
          Top = 97
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Tipo de Nota (Entrada)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 68
        end
        object RxDBLookupCombo7: TUniDBLookupComboBox
          Left = 124
          Top = 97
          Width = 450
          Height = 21
          DataField = 'Tipo_Nota'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 9
        end
        object GroupBox1: TUniGroupBox
          Left = 4
          Top = 464
          Width = 774
          Height = 42
          Caption = 'Cliente Importador'
          Font.Color = clBlue
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 40
          object cNomeClienteImp: TUniDBEdit
            Left = 61
            Top = 16
            Width = 438
            Height = 21
            DataField = 'Cliente_ImpNome'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
          object StaticText1: TUniLabel
            Left = 6
            Top = 16
            Width = 53
            Height = 21
            AutoSize = False
            Caption = 'Nome'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 2
          end
          object StaticText28: TUniLabel
            Left = 502
            Top = 16
            Width = 53
            Height = 21
            AutoSize = False
            Caption = 'Estado'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 3
          end
          object RxDBLookupCombo8: TUniDBLookupComboBox
            Left = 557
            Top = 16
            Width = 205
            Height = 21
            DataField = 'Cliente_ImpEstado'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
        end
        object GroupBox2: TUniGroupBox
          Left = 4
          Top = 510
          Width = 774
          Height = 71
          Caption = 'Cliente Nota Fiscal'
          Font.Color = clBlue
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 41
          object StaticText34: TUniLabel
            Left = 6
            Top = 16
            Width = 53
            Height = 21
            AutoSize = False
            Caption = 'Nome'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 4
          end
          object StaticText35: TUniLabel
            Left = 502
            Top = 16
            Width = 53
            Height = 21
            AutoSize = False
            Caption = 'Estado'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 6
          end
          object DBEdit19: TUniDBEdit
            Left = 61
            Top = 16
            Width = 438
            Height = 21
            DataField = 'Cliente_NotaNome'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
          object DBCheckBox1: TUniDBCheckBox
            Left = 11
            Top = 45
            Width = 77
            Height = 17
            Caption = 'Contribuinte'
            DataField = 'Cliente_NotaContrib'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'MS Sans Serif'
            Font.Style = []
            ParentFont = False
            TabOrder = 2
          end
          object DBCheckBox2: TUniDBCheckBox
            Left = 228
            Top = 45
            Width = 102
            Height = 17
            Caption = 'Simples Nacional'
            DataField = 'Cliente_NotaSimples'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'MS Sans Serif'
            Font.Style = []
            ParentFont = False
            TabOrder = 3
          end
          object DBCheckBox3: TUniDBCheckBox
            Left = 107
            Top = 45
            Width = 95
            Height = 17
            Caption = 'Pessoa Juridica'
            DataField = 'Cliente_NotaJuridica'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'MS Sans Serif'
            Font.Style = []
            ParentFont = False
            TabOrder = 5
          end
          object RxDBLookupCombo9: TUniDBLookupComboBox
            Left = 557
            Top = 16
            Width = 205
            Height = 21
            DataField = 'Cliente_NotaEstado'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
          object DBCheckBox4: TUniDBCheckBox
            Left = 355
            Top = 45
            Width = 83
            Height = 17
            Caption = 'Zona Franca'
            DataField = 'Cliente_NotaZonaFranca'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'MS Sans Serif'
            Font.Style = []
            ParentFont = False
            TabOrder = 7
          end
          object DBCheckBox5: TUniDBCheckBox
            Left = 459
            Top = 45
            Width = 102
            Height = 17
            Caption = 'Consumidor Final'
            DataField = 'Cliente_NotaConsumidorFinal'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'MS Sans Serif'
            Font.Style = []
            ParentFont = False
            TabOrder = 8
          end
          object DBCheckBox6: TUniDBCheckBox
            Left = 581
            Top = 45
            Width = 184
            Height = 17
            Caption = 'N'#227'o destacar impostos creditaveis'
            DataField = 'Destacar_ImpCred'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'MS Sans Serif'
            Font.Style = []
            ParentFont = False
            TabOrder = 9
          end
        end
        object StaticText36: TUniLabel
          Left = 4
          Top = 74
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'INCOTERM'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 69
        end
        object RxDBLookupCombo10: TUniDBLookupComboBox
          Left = 124
          Top = 74
          Width = 450
          Height = 21
          DataField = 'INCOTERM'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 8
        end
        object StaticText37: TUniLabel
          Left = 390
          Top = 5
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'N'#186' do Processo'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 70
        end
        object DBEdit3: TUniDBEdit
          Left = 510
          Top = 5
          Width = 171
          Height = 21
          DataField = 'Processo'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 3
        end
        object StaticText38: TUniLabel
          Left = 4
          Top = 28
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Tipo de Produto'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 71
        end
        object DBEdit6: TUniDBEdit
          Left = 124
          Top = 28
          Width = 260
          Height = 21
          DataField = 'Tipo_Produto'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 4
        end
        object StaticText54: TUniLabel
          Left = 4
          Top = 373
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Fator'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 72
        end
        object DBEdit22: TUniDBEdit
          Left = 124
          Top = 373
          Width = 100
          Height = 21
          DataField = 'Fator'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 31
        end
        object StaticText58: TUniLabel
          Left = 4
          Top = 120
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Tipo de Nota (Sa'#237'da)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 73
        end
        object RxDBLookupCombo11: TUniDBLookupComboBox
          Left = 124
          Top = 120
          Width = 450
          Height = 21
          DataField = 'Tipo_NotaSai'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 10
        end
        object StaticText60: TUniLabel
          Left = 450
          Top = 396
          Width = 68
          Height = 21
          AutoSize = False
          Caption = 'ICMS Entrada'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 74
        end
        object DBEdit40: TUniDBEdit
          Left = 519
          Top = 396
          Width = 50
          Height = 21
          DataField = 'Aliquota_ICMSEntrada'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 37
        end
        object DBEdit41: TUniDBEdit
          Left = 631
          Top = 396
          Width = 58
          Height = 21
          DataField = 'Aliquota_ICMSSaida'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 38
        end
        object StaticText61: TUniLabel
          Left = 571
          Top = 396
          Width = 58
          Height = 21
          AutoSize = False
          Caption = 'ICMSSa'#237'da'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 75
        end
        object RxDBLookupCombo12: TUniDBLookupComboBox
          Left = 124
          Top = 51
          Width = 262
          Height = 21
          DataField = 'Modalidade'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 6
        end
        object StaticText67: TUniLabel
          Left = 390
          Top = 28
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Produto Destinado a'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 76
        end
        object DBEdit47: TUniDBEdit
          Left = 510
          Top = 28
          Width = 268
          Height = 21
          DataField = 'Produto_Destinado'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 5
        end
        object GroupBox3: TUniGroupBox
          Left = 4
          Top = 419
          Width = 774
          Height = 41
          Caption = 'Servi'#231'os (Impostos e Taxas)'
          Font.Color = clBlue
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 39
          object StaticText69: TUniLabel
            Left = 159
            Top = 15
            Width = 30
            Height = 21
            AutoSize = False
            Caption = 'PIS'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 6
          end
          object DBEdit49: TUniDBEdit
            Left = 191
            Top = 15
            Width = 44
            Height = 21
            DataField = 'Aliquota_PISServ'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 1
          end
          object StaticText70: TUniLabel
            Left = 446
            Top = 15
            Width = 42
            Height = 21
            AutoSize = False
            Caption = 'CSLL'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 7
          end
          object DBEdit50: TUniDBEdit
            Left = 490
            Top = 15
            Width = 50
            Height = 21
            DataField = 'Aliquota_CSLLServ'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 4
          end
          object DBEdit51: TUniDBEdit
            Left = 294
            Top = 15
            Width = 50
            Height = 21
            DataField = 'Aliquota_COFINSServ'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 2
          end
          object StaticText71: TUniLabel
            Left = 244
            Top = 15
            Width = 48
            Height = 21
            AutoSize = False
            Caption = 'COFINS'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 8
          end
          object StaticText72: TUniLabel
            Left = 348
            Top = 15
            Width = 42
            Height = 21
            AutoSize = False
            Caption = 'IRPJ'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 9
          end
          object DBEdit52: TUniDBEdit
            Left = 392
            Top = 15
            Width = 50
            Height = 21
            DataField = 'Aliquota_IRPJServ'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 3
          end
          object StaticText73: TUniLabel
            Left = 545
            Top = 15
            Width = 42
            Height = 21
            AutoSize = False
            Caption = 'ISS'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 10
          end
          object DBEdit53: TUniDBEdit
            Left = 589
            Top = 15
            Width = 50
            Height = 21
            DataField = 'Aliquota_ISSServ'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 5
          end
          object StaticText68: TUniLabel
            Left = 6
            Top = 15
            Width = 67
            Height = 21
            AutoSize = False
            Caption = 'Taxa Servi'#231'o'
            Color = 7293440
            Font.Color = clWhite
            Font.Height = -11
            Font.Name = 'Calibri'
            Font.Style = [fsBold]
            ParentColor = False
            ParentFont = False
            TabOrder = 11
          end
          object DBEdit48: TUniDBEdit
            Left = 75
            Top = 15
            Width = 80
            Height = 21
            DataField = 'Taxa_Servico'
            Font.Color = clWindowText
            Font.Height = -11
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            TabOrder = 0
          end
        end
        object StaticText124: TUniLabel
          Left = 478
          Top = 350
          Width = 81
          Height = 21
          AutoSize = False
          Caption = 'AFRMM'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 77
        end
        object DBEdit54: TUniDBEdit
          Left = 561
          Top = 350
          Width = 95
          Height = 21
          DataField = 'Valor_AFRMM'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 78
        end
        object StaticText53: TUniLabel
          Left = 4
          Top = 327
          Width = 118
          Height = 21
          AutoSize = False
          Caption = 'Moeda Seguro'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 79
        end
        object RxDBLookupCombo6: TUniDBLookupComboBox
          Left = 124
          Top = 327
          Width = 247
          Height = 21
          DataField = 'Moeda_Seguro'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 80
        end
        object StaticText19: TUniLabel
          Left = 374
          Top = 327
          Width = 34
          Height = 21
          AutoSize = False
          Caption = 'Taxa'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 81
        end
        object DBEdit21: TUniDBEdit
          Left = 410
          Top = 327
          Width = 66
          Height = 21
          DataField = 'Taxa_Seguro'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 82
        end
        object StaticText9: TUniLabel
          Left = 478
          Top = 327
          Width = 81
          Height = 21
          AutoSize = False
          Caption = 'Seguro (ME)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 83
        end
        object cSeguro: TUniDBEdit
          Left = 561
          Top = 327
          Width = 95
          Height = 21
          DataField = 'Seguro_PremioValor'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 84
        end
        object StaticText24: TUniLabel
          Left = 658
          Top = 327
          Width = 25
          Height = 21
          AutoSize = False
          Caption = 'R$'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 85
        end
        object DBEdit26: TUniDBEdit
          Left = 685
          Top = 327
          Width = 94
          Height = 21
          Color = 16766421
          DataField = 'Seguro_Real'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 86
        end
      end
    end
    object TabSheet2: TUniTabSheet
      Caption = '&Produtos'
      object Panel6: TUniPanel
        Left = 3
        Top = 3
        Width = 787
        Height = 260
        Align = alTop
        Enabled = False
        TabOrder = 0
        object StaticText2: TUniLabel
          Left = 5
          Top = 5
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'Produto'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 0
        end
        object cProduto: TUniDBEdit
          Left = 103
          Top = 5
          Width = 669
          Height = 21
          DataField = 'Produto'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 1
        end
        object StaticText4: TUniLabel
          Left = 5
          Top = 28
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'NCM'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 17
        end
        object cNCM: TUniDBEdit
          Left = 103
          Top = 28
          Width = 106
          Height = 21
          Color = 16438246
          DataField = 'NCM'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
        end
        object StaticText7: TUniLabel
          Left = 5
          Top = 51
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'Peso L'#237'quido'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 18
        end
        object DBEdit10: TUniDBEdit
          Left = 103
          Top = 51
          Width = 106
          Height = 21
          DataField = 'Peso_Liquido'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 3
        end
        object StaticText17: TUniLabel
          Left = 5
          Top = 97
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'Valor Unit'#225'rio (ME)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 19
        end
        object cUnitario: TUniDBEdit
          Left = 103
          Top = 97
          Width = 106
          Height = 21
          DataField = 'Valor_UnitarioME'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 6
        end
        object StaticText6: TUniLabel
          Left = 5
          Top = 74
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'Quantidade'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 20
        end
        object DBEdit9: TUniDBEdit
          Left = 103
          Top = 74
          Width = 106
          Height = 21
          DataField = 'Quantidade'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 5
        end
        object StaticText12: TUniLabel
          Left = 5
          Top = 120
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'II'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 21
        end
        object cAliquotaII: TUniDBEdit
          Left = 103
          Top = 120
          Width = 66
          Height = 21
          DataField = 'Aliquota_II'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 8
        end
        object StaticText13: TUniLabel
          Left = 5
          Top = 143
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'IPI'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 22
        end
        object cAliquotaIPI: TUniDBEdit
          Left = 103
          Top = 143
          Width = 66
          Height = 21
          DataField = 'Aliquota_IpI'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 10
        end
        object StaticText25: TUniLabel
          Left = 5
          Top = 166
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'PIS (Entrada)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 23
        end
        object cAliquotaPIS: TUniDBEdit
          Left = 103
          Top = 166
          Width = 66
          Height = 21
          DataField = 'Aliquota_PIS'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 12
        end
        object StaticText26: TUniLabel
          Left = 5
          Top = 189
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'COFINS (Entrada)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 24
        end
        object cAliquotaCOFINS: TUniDBEdit
          Left = 103
          Top = 189
          Width = 66
          Height = 21
          DataField = 'Aliquota_COFINS'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 14
        end
        object cPesoBruto: TUniDBEdit
          Left = 371
          Top = 51
          Width = 121
          Height = 21
          DataField = 'Peso_Bruto'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 4
        end
        object StaticText41: TUniLabel
          Left = 280
          Top = 51
          Width = 89
          Height = 21
          AutoSize = False
          Caption = 'Peso Bruto'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 25
        end
        object DBEdit13: TUniDBEdit
          Left = 171
          Top = 120
          Width = 106
          Height = 21
          DataField = 'Valor_II'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 9
        end
        object DBEdit14: TUniDBEdit
          Left = 171
          Top = 143
          Width = 106
          Height = 21
          DataField = 'Valor_IPI'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 11
        end
        object DBEdit15: TUniDBEdit
          Left = 171
          Top = 166
          Width = 106
          Height = 21
          DataField = 'Valor_PIS'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 13
        end
        object DBEdit23: TUniDBEdit
          Left = 171
          Top = 189
          Width = 106
          Height = 21
          DataField = 'Valor_COFINS'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 15
        end
        object cUnitarioReal: TUniNumberEdit
          Left = 371
          Top = 97
          Width = 121
          Height = 21
          TabStop = False
          AutoSize = False
          DisplayFormat = ',##0.000000'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 7
        end
        object StaticText42: TUniLabel
          Left = 280
          Top = 97
          Width = 89
          Height = 21
          AutoSize = False
          Caption = 'Valor Unit'#225'rio (R$)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 26
        end
        object StaticText46: TUniLabel
          Left = 5
          Top = 212
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'ICMS (Entrada)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 27
        end
        object DBEdit35: TUniDBEdit
          Left = 171
          Top = 212
          Width = 106
          Height = 21
          DataField = 'Valor_ICMSEntrada'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 16
        end
        object DBEdit33: TUniDBEdit
          Left = 103
          Top = 212
          Width = 66
          Height = 21
          DataField = 'Aliquota_ICMSEntrada'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 28
        end
        object StaticText55: TUniLabel
          Left = 280
          Top = 166
          Width = 89
          Height = 21
          AutoSize = False
          Caption = 'PIS (Sa'#237'da)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 29
        end
        object DBEdit12: TUniDBEdit
          Left = 371
          Top = 166
          Width = 66
          Height = 21
          DataField = 'Aliquota_PISSai'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 30
        end
        object StaticText56: TUniLabel
          Left = 280
          Top = 189
          Width = 89
          Height = 21
          AutoSize = False
          Caption = 'COFINS (Sa'#237'da)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 31
        end
        object DBEdit27: TUniDBEdit
          Left = 371
          Top = 189
          Width = 66
          Height = 21
          DataField = 'Aliquota_COFINSSai'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 32
        end
        object DBEdit30: TUniDBEdit
          Left = 439
          Top = 166
          Width = 102
          Height = 21
          DataField = 'Valor_PISSai'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 33
          Visible = False
        end
        object DBEdit31: TUniDBEdit
          Left = 439
          Top = 189
          Width = 102
          Height = 21
          DataField = 'Valor_COFINSSai'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 34
          Visible = False
        end
        object StaticText57: TUniLabel
          Left = 280
          Top = 212
          Width = 89
          Height = 21
          AutoSize = False
          Caption = 'ICMS (Sa'#237'da)'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 35
        end
        object DBEdit34: TUniDBEdit
          Left = 439
          Top = 212
          Width = 102
          Height = 21
          DataField = 'Valor_ICMSSaida'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 36
        end
        object DBEdit38: TUniDBEdit
          Left = 371
          Top = 212
          Width = 66
          Height = 21
          DataField = 'Aliquota_ICMS'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 37
        end
        object StaticText63: TUniLabel
          Left = 5
          Top = 235
          Width = 96
          Height = 21
          AutoSize = False
          Caption = 'ICMS ST'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 38
        end
        object DBEdit43: TUniDBEdit
          Left = 171
          Top = 235
          Width = 106
          Height = 21
          DataField = 'Valor_ICMSST'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 39
        end
        object DBEdit44: TUniDBEdit
          Left = 103
          Top = 235
          Width = 66
          Height = 21
          DataField = 'Aliquota_ICMSST'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 40
        end
        object StaticText64: TUniLabel
          Left = 280
          Top = 235
          Width = 89
          Height = 21
          AutoSize = False
          Caption = 'MVA'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 41
        end
        object DBEdit45: TUniDBEdit
          Left = 371
          Top = 235
          Width = 66
          Height = 21
          DataField = 'Aliquota_MVA'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 42
        end
        object cTotalII: TUniNumberEdit
          Left = 280
          Top = 120
          Width = 96
          Height = 21
          DisplayFormat = ',0.00;'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 43
        end
        object cTotalIPI: TUniNumberEdit
          Left = 280
          Top = 143
          Width = 96
          Height = 21
          DisplayFormat = ',0.00;'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 44
        end
        object DBEdit46: TUniDBEdit
          Left = 713
          Top = 212
          Width = 58
          Height = 21
          DataField = 'Aliquota_ICMSRed2'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 45
        end
      end
      object GradeProd: TUniDBGrid
        Left = 3
        Top = 306
        Width = 787
        Height = 285
        Align = alClient
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Calibri'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
      end
      object Panel4: TUniPanel
        Left = 3
        Top = 269
        Width = 787
        Height = 31
        Align = alTop
        TabOrder = 2
        object NavegaProdutos: TUniDBNavigator
          Left = 1
          Top = 1
          Width = 334
          Height = 29
          Align = alLeft
          ShowHint = True
          TabOrder = 0
        end
        object bDuplicarItem: TUniButton
          Left = 335
          Top = 1
          Width = 88
          Height = 29
          Align = alLeft
          Caption = 'Duplicar &Item'
          TabOrder = 1
        end
      end
      object StaticText62: TUniLabel
        Left = 547
        Top = 214
        Width = 99
        Height = 21
        AutoSize = False
        Caption = 'ICMS (Redu'#231#227'o 1/2)'
        Color = 7293440
        Font.Color = clWhite
        Font.Height = -11
        Font.Name = 'Calibri'
        Font.Style = [fsBold]
        ParentColor = False
        ParentFont = False
        TabOrder = 3
      end
      object DBEdit42: TUniDBEdit
        Left = 648
        Top = 214
        Width = 66
        Height = 21
        DataField = 'Aliquota_ICMSRed'
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
        TabOrder = 4
      end
    end
    object TabSheet3: TUniTabSheet
      Caption = '&Despesas'
      object gDespesas: TUniDBGrid
        Left = 2
        Top = 132
        Width = 781
        Height = 425
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Calibri'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object Panel3: TUniPanel
        Left = 3
        Top = 96
        Width = 787
        Height = 30
        Align = alTop
        TabOrder = 1
        object bRemoveTudo: TUniButton
          Left = 271
          Top = 1
          Width = 88
          Height = 28
          Align = alLeft
          Caption = 'Remover &Tudo'
          Font.Color = clBlack
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = []
          ParentFont = False
          TabOrder = 1
        end
        object bBuscar: TUniButton
          Left = 359
          Top = 1
          Width = 144
          Height = 28
          Align = alLeft
          Caption = '&Buscar Processo Existente'
          Font.Color = clBlack
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = []
          ParentFont = False
          TabOrder = 0
        end
        object bMarinha: TUniButton
          Left = 503
          Top = 1
          Width = 104
          Height = 28
          Align = alLeft
          Caption = '&Marinha Mercante'
          Font.Color = clBlack
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = []
          ParentFont = False
          TabOrder = 2
        end
        object NavegaDesp: TUniDBNavigator
          Left = 1
          Top = 1
          Width = 270
          Height = 28
          Align = alLeft
          ShowHint = True
          TabOrder = 3
        end
        object bPISCOFINS: TUniButton
          Left = 607
          Top = 1
          Width = 130
          Height = 28
          Align = alLeft
          Caption = '&Diferen'#231'a PIS/COFINS'
          Font.Color = clBlack
          Font.Height = -11
          Font.Name = 'MS Sans Serif'
          Font.Style = []
          ParentFont = False
          TabOrder = 4
        end
      end
      object StaticText30: TUniLabel
        Left = 147
        Top = 563
        Width = 147
        Height = 21
        AutoSize = False
        Caption = 'Total das Despesas  (Entrada)'
        Color = 7293440
        Font.Color = clWhite
        Font.Height = -11
        Font.Name = 'Calibri'
        Font.Style = [fsBold]
        ParentColor = False
        ParentFont = False
        TabOrder = 2
      end
      object cTotalDespesasSai: TUniNumberEdit
        Left = 547
        Top = 563
        Width = 110
        Height = 21
        AutoSize = False
        Color = 16764262
        DisplayFormat = ',0.00;-,0.00'
        Enabled = False
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
        TabOrder = 3
      end
      object cTotalDespesas: TUniNumberEdit
        Left = 295
        Top = 563
        Width = 99
        Height = 21
        AutoSize = False
        Color = 16764262
        DisplayFormat = ',0.00;-,0.00'
        Enabled = False
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
        TabOrder = 4
      end
      object Panel2: TUniPanel
        Left = 3
        Top = 3
        Width = 787
        Height = 87
        Align = alTop
        Enabled = False
        TabOrder = 5
        object bPesq: TUniSpeedButton
          Left = 403
          Top = 50
          Width = 23
          Height = 23
        end
        object StaticText20: TUniLabel
          Left = 652
          Top = 51
          Width = 21
          Height = 21
          AutoSize = False
          Caption = 'R$'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 2
        end
        object StaticText33: TUniLabel
          Left = 5
          Top = 51
          Width = 46
          Height = 21
          AutoSize = False
          Caption = 'Despesa'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 3
        end
        object cDespNac: TUniNumberEdit
          Left = 675
          Top = 51
          Width = 101
          Height = 21
          AutoSize = False
          DisplayFormat = ',##0.00'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 4
        end
        object StaticText59: TUniLabel
          Left = 530
          Top = 51
          Width = 23
          Height = 21
          AutoSize = False
          Caption = 'ME'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 5
        end
        object cValorME: TUniNumberEdit
          Left = 555
          Top = 51
          Width = 94
          Height = 21
          AutoSize = False
          DisplayFormat = ',##0.00'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 6
        end
        object StaticText65: TUniLabel
          Left = 430
          Top = 51
          Width = 29
          Height = 21
          AutoSize = False
          Caption = 'Taxa'
          Color = 7293440
          Font.Color = clWhite
          Font.Height = -11
          Font.Name = 'Calibri'
          Font.Style = [fsBold]
          ParentColor = False
          ParentFont = False
          TabOrder = 7
        end
        object cTaxa: TUniNumberEdit
          Left = 461
          Top = 51
          Width = 65
          Height = 21
          AutoSize = False
          DisplayFormat = '##0.0000'
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 8
        end
        object DBEdit39: TUniDBEdit
          Left = 689
          Top = 5
          Width = 84
          Height = 21
          DataField = 'Registro'
          Enabled = False
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Tahoma'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 9
          Visible = False
        end
      end
      object StaticText66: TUniLabel
        Left = 399
        Top = 563
        Width = 147
        Height = 21
        AutoSize = False
        Caption = 'Total das Despesas  (Sa'#237'da)'
        Color = 7293440
        Font.Color = clWhite
        Font.Height = -11
        Font.Name = 'Calibri'
        Font.Style = [fsBold]
        ParentColor = False
        ParentFont = False
        TabOrder = 6
      end
    end
    object TabSheet5: TUniTabSheet
      Caption = 'Lista'
      object DBGrid1: TUniDBGrid
        Left = 0
        Top = 0
        Width = 793
        Height = 594
        Align = alClient
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Calibri'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
    end
    object TabSheet4: TUniTabSheet
      Caption = 'Formulas dos C'#225'lculos'
      object Memo1: TUniMemo
        Left = 0
        Top = 0
        Width = 793
        Height = 594
        Align = alClient
        Color = 12320767
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Courier New'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
    end
  end
  object Panel1: TUniPanel
    Left = 0
    Top = 684
    Width = 807
    Height = 31
    Align = alBottom
    TabOrder = 1
    object bCalcular: TUniSpeedButton
      Left = 307
      Top = 1
      Width = 74
      Height = 29
      Hint = '  Recalcula todos os totais  '
      Align = alLeft
      Caption = '&Calcular'
      ShowHint = True
    end
    object bSair: TUniButton
      Left = 735
      Top = 1
      Width = 71
      Height = 29
      Hint = 'Fecha a janela atual e cancela os processos pendentes.'
      Align = alRight
      Caption = '&Sair'
      ShowHint = True
      TabOrder = 0
    end
    object bImprimir: TUniButton
      Left = 570
      Top = 1
      Width = 77
      Height = 29
      Align = alLeft
      Caption = '&Imprimir Vert'
      TabOrder = 1
    end
    object Navega: TUniDBNavigator
      Left = 1
      Top = 1
      Width = 306
      Height = 29
      Align = alLeft
      ShowHint = True
      TabOrder = 2
    end
    object bExcel: TUniButton
      Left = 495
      Top = 1
      Width = 75
      Height = 29
      Align = alLeft
      Caption = '&Gerar Excel'
      TabOrder = 3
    end
    object bDuplicar: TUniButton
      Left = 381
      Top = 1
      Width = 114
      Height = 29
      Align = alLeft
      Caption = '&Duplicar Simula'#231#227'o'
      TabOrder = 4
    end
    object bImpHor: TUniButton
      Left = 647
      Top = 1
      Width = 81
      Height = 29
      Align = alLeft
      Caption = '&Imprimir Horiz'
      TabOrder = 5
    end
  end
  object tNumero: TFDQuery
    Left = 426
    Top = 47
  end
  object tDespesa: TFDQuery
    Left = 618
    Top = 63
  end
  object tRegistro: TFDQuery
    Left = 386
    Top = 7
  end
  object tSomaDespesas: TFDQuery
    Left = 490
    Top = 7
  end
  object tItens: TFDQuery
    Left = 570
    Top = 7
  end
  object tSomaProdutos: TFDQuery
    Left = 530
    Top = 63
  end
  object tSomaImpostos: TFDQuery
    Left = 530
    Top = 119
  end
  object tProdutos: TFDQuery
    Left = 306
    Top = 6
  end
  object tSimula: TFDQuery
    Left = 242
    Top = 9
  end
  object dstSimula: TDataSource
    DataSet = tSimula
    Left = 240
    Top = 56
  end
  object dstProdutos: TDataSource
    DataSet = tProdutos
    Left = 304
    Top = 56
  end
  object dstDespesa: TDataSource
    DataSet = tDespesa
    Left = 616
    Top = 112
  end
  object tDespesaAdm: TFDQuery
    Left = 618
    Top = 167
  end
  object dstDespesaAdm: TDataSource
    DataSet = tDespesaAdm
    Left = 620
    Top = 215
  end
  object tDespesaSai: TFDQuery
    Left = 538
    Top = 175
  end
  object dstDespesaSai: TDataSource
    DataSet = tDespesaSai
    Left = 536
    Top = 224
  end
  object ttmp: TFDQuery
    Left = 424
    Top = 100
  end
  object tDespesaMar: TFDQuery
    Left = 289
    Top = 358
  end
  object dstDespesaMar: TDataSource
    DataSet = tDespesaMar
    Left = 289
    Top = 406
  end
end
